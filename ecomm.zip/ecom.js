document.addEventListener('DOMContentLoaded', () => {
    const productList = document.querySelector('.product-list');

    fetch('/api/products')
        .then(response => response.json())
        .then(products => {
            products.forEach(product => {
                const productItem = document.createElement('div');
                productItem.classList.add('product-item');
                productItem.innerHTML = `
                    <h3>${product.name}</h3>
                    <p>Price: $${product.price}</p>
                `;
                productList.appendChild(productItem);
            });
        });
});
/*Home page*/
document.addEventListener('DOMContentLoaded', () => {
    const productList = document.querySelector('.product-list');

    fetch('/api/products')
        .then(response => response.json())
        .then(products => {
            products.forEach(product => {
                const productItem = document.createElement('div');
                productItem.classList.add('product-item');
                productItem.innerHTML = `
                    <h3>${product.name}</h3>
                    <p>Price: $${product.price}</p>
                `;
                productList.appendChild(productItem);
            });
        });
});
/*Product page*/
document.addEventListener('DOMContentLoaded', () => {
    const productList = document.querySelector('.products');

    const products = [
        { name: 'Notes', price: 5.99, description: 'Comprehensive study notes for various subjects.' },
        { name: 'Handwritten Notes', price: 7.99, description: 'Beautifully handwritten notes for better retention.' },
        { name: 'Online Study Hacks', price: 4.99, description: 'Tips and tricks for effective online studying.' },
        { name: 'Easy PC Tricks', price: 3.99, description: 'Simple yet powerful tricks to enhance your PC experience.' },
        { name: 'Exam Preparation', price: 6.99, description: 'Key strategies for acing your exams.' },
        { name: 'Project Templates', price: 8.99, description: 'Ready-to-use templates for your school projects.' }
    ];

    products.forEach(product => {
        const productItem = document.createElement('div');
        productItem.classList.add('product-item');
        productItem.innerHTML = `
            <h3>${product.name}</h3>
            <p>${product.description}</p>
            <p>Price: $${product.price.toFixed(2)}</p>
            <button>Add to Cart</button>
        `;
        productList.appendChild(productItem);
    });
});
/*Cart page*/
document.addEventListener('DOMContentLoaded', () => {
    const cartItemsContainer = document.querySelector('.cart-items');
    const totalPriceElement = document.getElementById('total-price');

    const cartItems = [
        { name: 'Notes', price: 5.99, quantity: 2 },
        { name: 'Handwritten Notes', price: 7.99, quantity: 1 },
        { name: 'Online Study Hacks', price: 4.99, quantity: 3 }
    ];

    let totalPrice = 0;

    cartItems.forEach(item => {
        const cartItem = document.createElement('div');
        cartItem.classList.add('cart-item');
        cartItem.innerHTML = `
            <h3>${item.name}</h3>
            <p>Price: $${item.price.toFixed(2)}</p>
            <p>Quantity: ${item.quantity}</p>
        `;
        cartItemsContainer.appendChild(cartItem);

        totalPrice += item.price * item.quantity;
    });

    totalPriceElement.textContent = totalPrice.toFixed(2);

    document.getElementById('checkout-btn').addEventListener('click', () => {
        alert('Proceeding to checkout');
    });
});
/*login page*/
function validateLoginForm() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Validate username
    if (username.length < 6) {
        alert('Username should be at least 6 characters long.');
        return false;
    }

    // Validate password
    if (password.length < 6) {
        alert('Password should be at least 6 characters long.');
        return false;
    }

    return true;
}
